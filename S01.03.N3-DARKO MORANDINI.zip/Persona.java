
import java.util.Random;

public class Persona implements Comparable<Persona>{

	private String nombre;
	private String apellido;
	private String dni;
	
	public Persona(String nombre, String apellido) {
		this.nombre = nombre;
		this.apellido = apellido;
		dni=generarDNI();
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	
	public String getDni() {
		return dni;
	}
	
	@Override
	public int compareTo(Persona otraPersona) {
	    int comp = this.dni.compareTo(otraPersona.dni);
	    if (comp == 0) {
	        comp = this.nombre.compareTo(otraPersona.nombre);
	        if (comp == 0) {
	            comp = this.apellido.compareTo(otraPersona.apellido);
	        }
	    }
	    return comp;
	}
	
	public String generarDNI() {
        Random random = new Random();
        StringBuilder dni = new StringBuilder();
       
        for (int i = 0; i < 8; i++) {
            int digito = random.nextInt(10); 
            dni.append(digito);
        }
       
        int indiceLetra = random.nextInt(23); 
        char letra = obtenerLetraDNI(indiceLetra);

        return dni.toString() + letra;
    }

    public char obtenerLetraDNI(int indice) {
        char[] letrasDNI = {'T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E'};
        return letrasDNI[indice];
    }
}
	

