import java.util.*;

public class App {

	public static void main(String[] args) {
	
		Set<Persona>listaPersonas = new TreeSet<Persona>();
		
		addPersona("Darko", "Morandini", listaPersonas);
		addPersona("Andrea", "Herrera", listaPersonas);
		addPersona("Ivan", "Alarcon", listaPersonas);
		addPersona("Lua", "Perez", listaPersonas);
		addPersona("Alessandro", "Morandini", listaPersonas);
		addPersona("Viridiana", "Morandini", listaPersonas);
		
		ordenaPorNombreAz(listaPersonas);
		System.out.println("-------------------------------");
		ordenaPorNombreZa(listaPersonas);
		System.out.println("-------------------------------");
		ordenaPorDniAscendente(listaPersonas);
		System.out.println("-------------------------------");
		ordenaPorDniDescendente(listaPersonas);
	}

	public static void addPersona(String nombre, String apellido, Set<Persona>listaPersonas) {
		
		Persona persona = new Persona(nombre, apellido);
		listaPersonas.add(persona);
		
	}

	public static void ordenaPorNombreZa(Set<Persona> listaPersonas) {
	   
		TreeSet<Persona> personas = new TreeSet<>(Collections.reverseOrder(new Comparator<Persona>() {
	        @Override
	        public int compare(Persona p1, Persona p2) {
	            return p1.getNombre().compareTo(p2.getNombre());
	        }
	    }));
	    personas.addAll(listaPersonas);
	    for (Persona persona : personas) {
	        System.out.println(persona.getNombre() + " " + persona.getApellido() + " " + persona.getDni());
	    }
	}
			
	public static void ordenaPorNombreAz(Set<Persona> listaPersonas) {
	    Set<Persona> personasOrdenadas = new TreeSet<>(new Comparator<Persona>() {
	        @Override
	        public int compare(Persona p1, Persona p2) {
	            return p1.getNombre().compareTo(p2.getNombre());
	        }
	    });
	    personasOrdenadas.addAll(listaPersonas);
	    for (Persona persona : personasOrdenadas) {
	        System.out.println(persona.getNombre() + " " + persona.getApellido() + " " + persona.getDni());
	    }
	}

	public static void ordenaPorDniDescendente(Set<Persona> listaPersonas) {
		   
		TreeSet<Persona> personas = new TreeSet<>(Collections.reverseOrder(new Comparator<Persona>() {
	        @Override
	        public int compare(Persona p1, Persona p2) {
	            return p1.getDni().compareTo(p2.getDni());
	        }
	    }));
	    personas.addAll(listaPersonas);
	    for (Persona persona : personas) {
	        System.out.println(persona.getNombre() + " " + persona.getApellido() + " " + persona.getDni());
	    }
	}


	public static void ordenaPorDniAscendente(Set<Persona> listaPersonas) {
		
		ArrayList<Persona> personas = new ArrayList<Persona>(listaPersonas);
	    Collections.sort(personas, new Comparator<Persona>() {
	        @Override
	        public int compare(Persona p1, Persona p2) {
	            return p1.getDni().compareTo(p2.getDni());
	        }
	    });
	    for (Persona persona : personas) {
	        System.out.println(persona.getNombre() + " " + persona.getApellido() + " " + persona.getDni());
	    }
	}
}
	

